# Cow Dataset Camera — In-app camera preview

This Android project opens a camera preview inside the app instead of launching the phone's separate Camera app. It uses CameraX for photo capture and video recording.

## Features
- In-app live camera preview for photos and videos
- Runtime camera permission prompt; microphone permission is requested for video and audio is included only if granted
- Saves media to `Pictures/CowDataset/cow1`, `cow2`, and so on
- NEW COW increments and persists the current cow number
- Timestamped filenames to avoid overwriting existing media
- Java/Kotlin JVM target 17

## Build
Upload this project ZIP to AndroidForge and choose the Android/debug build if prompted. The first build downloads CameraX dependencies, so it may take longer than the previous version.

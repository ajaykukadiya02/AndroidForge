# Cow Dataset Camera (fixed capture flow)

Android app for collecting cow photos and videos into sequential folders:
`Pictures/CowDataset/cow1`, `cow2`, etc.

## Capture reliability changes
- Uses AndroidX Activity Result camera contracts, which pass the required URI permissions to the camera app.
- Keeps the pending media URI across activity recreation.
- Checks whether the camera actually wrote data before treating a canceled result as a failed capture.
- Finalizes or cleans up the temporary media row safely and prevents duplicate capture launches.
- Java and Kotlin are both configured for JVM 17.

## Build
Open this folder as a Gradle Android project, or upload the ZIP to a compatible Android build service. Use a debug build for testing.

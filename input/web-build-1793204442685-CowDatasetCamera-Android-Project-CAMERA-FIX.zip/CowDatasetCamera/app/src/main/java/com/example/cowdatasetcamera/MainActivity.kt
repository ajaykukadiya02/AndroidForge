package com.example.cowdatasetcamera

import android.content.ContentValues
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import java.io.FileNotFoundException

class MainActivity : ComponentActivity() {
    private val prefs by lazy { getSharedPreferences("cow_dataset", MODE_PRIVATE) }
    private var currentCow = 1
    private var pendingUri: Uri? = null
    private var pendingIsVideo = false
    private var pendingCow = 1
    private lateinit var status: TextView
    private lateinit var photoLauncher: ActivityResultLauncher<Uri>
    private lateinit var videoLauncher: ActivityResultLauncher<Uri>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Register result handlers before the activity reaches STARTED.
        photoLauncher = registerForActivityResult(ActivityResultContracts.TakePicture()) { result ->
            finishCapture(result)
        }
        videoLauncher = registerForActivityResult(ActivityResultContracts.CaptureVideo()) { result ->
            finishCapture(result)
        }

        currentCow = prefs.getInt("current_cow", 1).coerceAtLeast(1)
        if (savedInstanceState != null) {
            pendingUri = savedInstanceState.getString(STATE_PENDING_URI)?.let(Uri::parse)
            pendingIsVideo = savedInstanceState.getBoolean(STATE_PENDING_VIDEO, false)
            pendingCow = savedInstanceState.getInt(STATE_PENDING_COW, currentCow)
        }
        showHome()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putString(STATE_PENDING_URI, pendingUri?.toString())
        outState.putBoolean(STATE_PENDING_VIDEO, pendingIsVideo)
        outState.putInt(STATE_PENDING_COW, pendingCow)
        super.onSaveInstanceState(outState)
    }

    private fun showHome() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 32, 32, 32)
        }
        status = TextView(this).apply {
            textSize = 22f
            gravity = Gravity.CENTER
            text = "Current folder: cow$currentCow\n\nPhotos and videos save to\nPictures/CowDataset/cow$currentCow"
        }
        val photo = Button(this).apply {
            text = "CAPTURE PHOTO"
            textSize = 18f
            setOnClickListener { launchCapture(video = false) }
        }
        val video = Button(this).apply {
            text = "RECORD VIDEO"
            textSize = 18f
            setOnClickListener { launchCapture(video = true) }
        }
        val next = Button(this).apply {
            text = "NEW COW"
            textSize = 20f
            setOnClickListener {
                currentCow += 1
                prefs.edit().putInt("current_cow", currentCow).apply()
                showHome()
                Toast.makeText(this@MainActivity, "Now collecting cow$currentCow", Toast.LENGTH_SHORT).show()
            }
        }
        listOf(status, photo, video, next).forEach { view ->
            val lp = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(0, 12, 0, 12) }
            root.addView(view, lp)
        }
        setContentView(root)
    }

    private fun launchCapture(video: Boolean) {
        // Prevent two launches while another capture is still in progress.
        if (pendingUri != null) {
            Toast.makeText(this, "A capture is already in progress. Please finish it first.", Toast.LENGTH_LONG).show()
            return
        }

        val folderCow = currentCow
        val relativePath = "${Environment.DIRECTORY_PICTURES}/CowDataset/cow$folderCow"
        val timestamp = System.currentTimeMillis()
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME,
                "${if (video) "video" else "photo"}_$timestamp.${if (video) "mp4" else "jpg"}")
            put(MediaStore.MediaColumns.MIME_TYPE, if (video) "video/mp4" else "image/jpeg")
            put(MediaStore.MediaColumns.RELATIVE_PATH, relativePath)
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val collection = if (video) MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                         else MediaStore.Images.Media.EXTERNAL_CONTENT_URI

        val uri = try {
            contentResolver.insert(collection, values)
        } catch (e: Exception) {
            null
        }
        if (uri == null) {
            Toast.makeText(this, "Could not prepare a media file. Please try again.", Toast.LENGTH_LONG).show()
            return
        }

        pendingUri = uri
        pendingIsVideo = video
        pendingCow = folderCow
        status.text = "Opening camera for cow$folderCow…\n\nFinish or cancel the capture in the camera app."
        try {
            if (video) videoLauncher.launch(uri) else photoLauncher.launch(uri)
        } catch (e: Exception) {
            safelyDelete(uri)
            clearPending()
            status.text = homeStatusText()
            Toast.makeText(this, "Could not open camera. Please try again.", Toast.LENGTH_LONG).show()
        }
    }

    private fun finishCapture(cameraReportedSuccess: Boolean) {
        val uri = pendingUri ?: return
        val cowNumber = pendingCow
        try {
            // Some camera apps return CANCELED even when they wrote the requested output.
            // Treat a non-empty output as success rather than incorrectly deleting it.
            val hasData = mediaHasData(uri)
            if (cameraReportedSuccess || hasData) {
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.IS_PENDING, 0)
                }
                contentResolver.update(uri, values, null, null)
                Toast.makeText(this, "Saved to cow$cowNumber", Toast.LENGTH_LONG).show()
            } else {
                safelyDelete(uri)
                Toast.makeText(this, "Capture cancelled. No file was saved.", Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) {
            // Keep the app alive if a camera app or media provider behaves unexpectedly.
            if (mediaHasData(uri)) {
                try {
                    contentResolver.update(uri, ContentValues().apply {
                        put(MediaStore.MediaColumns.IS_PENDING, 0)
                    }, null, null)
                    Toast.makeText(this, "Media captured in cow$cowNumber, but finalizing it had a problem.", Toast.LENGTH_LONG).show()
                } catch (_: Exception) {
                    Toast.makeText(this, "Camera returned. Please check Pictures/CowDataset/cow$cowNumber.", Toast.LENGTH_LONG).show()
                }
            } else {
                safelyDelete(uri)
                Toast.makeText(this, "Capture did not finish. Please try again.", Toast.LENGTH_LONG).show()
            }
        } finally {
            clearPending()
            if (::status.isInitialized) status.text = homeStatusText()
        }
    }

    private fun mediaHasData(uri: Uri): Boolean {
        return try {
            contentResolver.openFileDescriptor(uri, "r")?.use { descriptor ->
                descriptor.statSize > 0L
            } ?: false
        } catch (_: FileNotFoundException) {
            false
        } catch (_: Exception) {
            false
        }
    }

    private fun safelyDelete(uri: Uri) {
        try { contentResolver.delete(uri, null, null) } catch (_: Exception) { /* best effort */ }
    }

    private fun clearPending() {
        pendingUri = null
        pendingIsVideo = false
        pendingCow = currentCow
    }

    private fun homeStatusText(): String =
        "Current folder: cow$currentCow\n\nPhotos and videos save to\nPictures/CowDataset/cow$currentCow"

    companion object {
        private const val STATE_PENDING_URI = "pending_uri"
        private const val STATE_PENDING_VIDEO = "pending_video"
        private const val STATE_PENDING_COW = "pending_cow"
    }
}

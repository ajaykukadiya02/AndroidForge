# Cow Dataset Camera — Smooth In-App Preview (source ZIP)

This is an Android Gradle source project, not a ready-to-install APK.

Features:
- In-app live camera preview; it does not launch the separate Camera app.
- Take photos and record videos from the preview.
- NEW COW remains visible on the camera screen; tap it to move to the next cow folder without leaving the preview. It is disabled logically while recording.
- Saves media to Pictures/CowDataset/cow1, cow2, and so on using MediaStore.
- Remembers the current cow number between app launches. Existing media is not deleted or overwritten; each capture gets a timestamped filename.
- Uses CameraX and asks Android for camera/microphone permissions when needed.
- Uses target SDK 34 to avoid Android 15 edge-to-edge layout covering the bottom controls.

Build requirements: Android Gradle Plugin 8.7.3, Kotlin 2.0.21, Java 17, compile SDK 35, CameraX 1.4.2.

Build note: this source includes a fix for the previous compile error by using the supported one-argument QualitySelector.from(Quality.HD) overload and explicitly including camera-video. It has been checked against the previously supplied AndroidForge compiler log, but this environment does not have an Android SDK/Gradle setup for a full APK build or physical-device test.

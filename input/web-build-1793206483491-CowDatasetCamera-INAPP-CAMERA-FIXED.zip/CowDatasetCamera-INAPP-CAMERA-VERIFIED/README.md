# Cow Dataset Camera — In-App Camera Preview (corrected source ZIP)

This is an Android Studio/Gradle source project, not an APK.

Features:
- CameraX live preview inside the app (does not launch the external Camera app).
- Take photos and record videos from the in-app preview.
- Media saved under Pictures/CowDataset/cow1, cow2, etc. using MediaStore.
- NEW COW increments and persists the current cow folder counter.
- Runtime camera and optional microphone permission prompts.
- Java and Kotlin JVM target are both set to 17.

Build with Android Gradle Plugin 8.7.3, Kotlin 2.0.21, compile SDK 35, and CameraX 1.4.2.

Note: The source has been statically inspected and the nullable CameraX use-case binding issue has been corrected. This environment does not have an Android SDK/Gradle installation, so a full device/build verification could not be run here. Build the ZIP with AndroidForge; if it fails, download and share that new run's AndroidForge-logs artifact so the exact error can be corrected.

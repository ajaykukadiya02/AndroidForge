package com.example.cowdatasetcamera

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : ComponentActivity() {
    private val prefs by lazy { getSharedPreferences("cow_dataset", MODE_PRIVATE) }
    private var currentCow = 1
    private var cameraProvider: ProcessCameraProvider? = null
    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: Recording? = null
    private var isVideoScreen = false
    private var isBindingCamera = false
    private lateinit var executor: ExecutorService
    private lateinit var status: TextView
    private lateinit var previewView: PreviewView
    private lateinit var captureButton: Button
    private lateinit var homeView: LinearLayout
    private lateinit var cameraView: LinearLayout

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
            val cameraGranted = result[Manifest.permission.CAMERA] == true ||
                ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
            if (cameraGranted) bindCameraUseCases()
            else {
                Toast.makeText(this, "Camera permission is required to capture cow photos/videos.", Toast.LENGTH_LONG).show()
                showHome()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        executor = Executors.newSingleThreadExecutor()
        currentCow = prefs.getInt("current_cow", 1).coerceAtLeast(1)
        showHome()
    }

    override fun onDestroy() {
        try { recording?.stop() } catch (_: Exception) {}
        executor.shutdown()
        super.onDestroy()
    }

    private fun showHome() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
        }
        val heading = TextView(this).apply {
            text = "COW DATASET CAMERA"
            textSize = 25f
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            textSize = 19f
            gravity = Gravity.CENTER
            text = homeStatus()
            setPadding(0, 30, 0, 24)
        }
        val photo = Button(this).apply {
            text = "CAPTURE PHOTO"
            textSize = 18f
            setOnClickListener { openCamera(video = false) }
        }
        val video = Button(this).apply {
            text = "RECORD VIDEO"
            textSize = 18f
            setOnClickListener { openCamera(video = true) }
        }
        val next = Button(this).apply {
            text = "NEW COW"
            textSize = 20f
            setOnClickListener {
                currentCow += 1
                prefs.edit().putInt("current_cow", currentCow).apply()
                status.text = homeStatus()
                Toast.makeText(this@MainActivity, "Now collecting cow$currentCow", Toast.LENGTH_SHORT).show()
            }
        }
        listOf(heading, status, photo, video, next).forEach { view ->
            root.addView(view, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                if (view == heading || view == status) ViewGroup.LayoutParams.WRAP_CONTENT else dp(56)
            ).apply { setMargins(0, dp(7), 0, dp(7)) })
        }
        homeView = root
        setContentView(root)
    }

    private fun openCamera(video: Boolean) {
        isVideoScreen = video
        showCameraUi()
        val needed = mutableListOf(Manifest.permission.CAMERA)
        if (video && ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.RECORD_AUDIO)
        }
        if (needed.all { ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED }) {
            bindCameraUseCases()
        } else {
            permissionLauncher.launch(needed.toTypedArray())
        }
    }

    private fun showCameraUi() {
        cameraView = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(6), dp(8), dp(6))
        }
        val back = Button(this).apply {
            text = "BACK"
            setOnClickListener {
                if (recording != null) stopRecording()
                cameraProvider?.unbindAll()
                showHome()
            }
        }
        val title = TextView(this).apply {
            text = if (isVideoScreen) "Record video · cow$currentCow" else "Take photo · cow$currentCow"
            textSize = 18f
            gravity = Gravity.CENTER
        }
        top.addView(back, LinearLayout.LayoutParams(dp(100), dp(48)))
        top.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        previewView = PreviewView(this).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }
        status = TextView(this).apply {
            text = "Starting camera…"
            gravity = Gravity.CENTER
            textSize = 16f
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        captureButton = Button(this).apply {
            text = if (isVideoScreen) "START RECORDING" else "TAKE PHOTO"
            textSize = 18f
            setOnClickListener {
                if (isVideoScreen) {
                    if (recording == null) startRecording() else stopRecording()
                } else takePhoto()
            }
        }
        cameraView.addView(top, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        cameraView.addView(previewView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        cameraView.addView(status, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        cameraView.addView(captureButton, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(62)).apply {
            setMargins(dp(18), dp(6), dp(18), dp(18))
        })
        setContentView(cameraView)
    }

    private fun bindCameraUseCases() {
        if (isBindingCamera) return
        isBindingCamera = true
        status.text = "Starting camera preview…"
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                val provider = future.get()
                cameraProvider = provider
                provider.unbindAll()
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                imageCapture = ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                    .build()
                val recorder = Recorder.Builder()
                    .setQualitySelector(QualitySelector.from(Quality.HD, QualitySelector.FALLBACK_STRATEGY_LOWER_QUALITY))
                    .build()
                videoCapture = VideoCapture.withOutput(recorder)
                val selector = CameraSelector.DEFAULT_BACK_CAMERA
                if (isVideoScreen) provider.bindToLifecycle(this, selector, preview, videoCapture)
                else provider.bindToLifecycle(this, selector, preview, imageCapture)
                status.text = if (isVideoScreen) "Preview ready. Tap Start Recording." else "Preview ready. Point at the cow and tap Take Photo."
            } catch (e: Exception) {
                status.text = "Could not start camera. Please return and try again."
                Toast.makeText(this, "Camera error: ${e.localizedMessage ?: "unknown error"}", Toast.LENGTH_LONG).show()
            } finally {
                isBindingCamera = false
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun takePhoto() {
        val capture = imageCapture ?: run {
            Toast.makeText(this, "Camera is not ready yet. Please wait.", Toast.LENGTH_SHORT).show()
            return
        }
        captureButton.isEnabled = false
        status.text = "Saving photo to cow$currentCow…"
        val name = "cow${currentCow}_photo_${timestamp()}.jpg"
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "${Environment.DIRECTORY_PICTURES}/CowDataset/cow$currentCow")
        }
        val output = ImageCapture.OutputFileOptions.Builder(
            contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values
        ).build()
        capture.takePicture(output, ContextCompat.getMainExecutor(this), object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                captureButton.isEnabled = true
                status.text = "Photo saved in Pictures/CowDataset/cow$currentCow"
                Toast.makeText(this@MainActivity, "Photo saved to cow$currentCow", Toast.LENGTH_SHORT).show()
            }
            override fun onError(exception: ImageCaptureException) {
                captureButton.isEnabled = true
                status.text = "Photo not saved. You can try again."
                Toast.makeText(this@MainActivity, "Photo error: ${exception.message ?: "please try again"}", Toast.LENGTH_LONG).show()
            }
        })
    }

    private fun startRecording() {
        val capture = videoCapture ?: run {
            Toast.makeText(this, "Camera is not ready yet. Please wait.", Toast.LENGTH_SHORT).show()
            return
        }
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "cow${currentCow}_video_${timestamp()}.mp4")
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "${Environment.DIRECTORY_PICTURES}/CowDataset/cow$currentCow")
        }
        val output = MediaStoreOutputOptions.Builder(contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
            .setContentValues(values).build()
        try {
            var pending = capture.output.prepareRecording(this, output)
            val hasAudio = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            if (hasAudio) pending = pending.withAudioEnabled()
            recording = pending.start(ContextCompat.getMainExecutor(this)) { event ->
                when (event) {
                    is VideoRecordEvent.Start -> {
                        captureButton.text = "STOP RECORDING"
                        status.text = "Recording… tap Stop Recording when finished."
                    }
                    is VideoRecordEvent.Finalize -> {
                        recording = null
                        captureButton.isEnabled = true
                        captureButton.text = "START RECORDING"
                        if (!event.hasError()) {
                            status.text = "Video saved in Pictures/CowDataset/cow$currentCow"
                            Toast.makeText(this, "Video saved to cow$currentCow", Toast.LENGTH_SHORT).show()
                        } else {
                            status.text = "Video not saved. Please try again."
                            Toast.makeText(this, "Video error: ${event.error}", Toast.LENGTH_LONG).show()
                        }
                    }
                }
            }
            captureButton.isEnabled = true
        } catch (e: Exception) {
            recording = null
            captureButton.isEnabled = true
            status.text = "Could not start recording. Please try again."
            Toast.makeText(this, "Recording error: ${e.localizedMessage ?: "unknown error"}", Toast.LENGTH_LONG).show()
        }
    }

    private fun stopRecording() {
        try {
            recording?.stop()
            captureButton.isEnabled = false
            status.text = "Finishing video…"
        } catch (e: Exception) {
            recording = null
            captureButton.isEnabled = true
            captureButton.text = "START RECORDING"
            status.text = "Recording stopped. Check saved videos."
        }
    }

    private fun homeStatus(): String =
        "Current folder: cow$currentCow\n\nPhotos and videos save to\nPictures/CowDataset/cow$currentCow"

    private fun timestamp(): String = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}

package com.example.cowdatasetcamera

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity

class MainActivity : ComponentActivity() {
    private val prefs by lazy { getSharedPreferences("cow_dataset", MODE_PRIVATE) }
    private var currentCow = 1
    private var pendingUri: Uri? = null
    private var pendingIsVideo = false
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        currentCow = prefs.getInt("current_cow", 1).coerceAtLeast(1)
        showHome()
    }

    private fun showHome() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 32, 32, 32)
        }
        status = TextView(this).apply {
            textSize = 24f
            gravity = Gravity.CENTER
            text = "Current folder: cow$currentCow\n\nPhotos and videos are saved to\nPictures/CowDataset/cow$currentCow"
        }
        val photo = Button(this).apply {
            text = "CAPTURE PHOTO"
            textSize = 18f
            setOnClickListener { launchCapture(false) }
        }
        val video = Button(this).apply {
            text = "RECORD VIDEO"
            textSize = 18f
            setOnClickListener { launchCapture(true) }
        }
        val next = Button(this).apply {
            text = "NEW COW"
            textSize = 20f
            setOnClickListener {
                currentCow += 1
                prefs.edit().putInt("current_cow", currentCow).apply()
                showHome()
                Toast.makeText(this@MainActivity, "Now collecting cow$currentCow", Toast.LENGTH_SHORT).show()
            }
        }
        listOf(status, photo, video, next).forEach { view ->
            val lp = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                if (view is TextView) ViewGroup.LayoutParams.WRAP_CONTENT else ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(0, 12, 0, 12) }
            root.addView(view, lp)
        }
        setContentView(root)
    }

    private fun launchCapture(video: Boolean) {
        val intent = Intent(if (video) MediaStore.ACTION_VIDEO_CAPTURE else MediaStore.ACTION_IMAGE_CAPTURE)
        if (intent.resolveActivity(packageManager) == null) {
            Toast.makeText(this, "No compatible camera app found", Toast.LENGTH_LONG).show()
            return
        }

        val relativePath = Environment.DIRECTORY_PICTURES + "/CowDataset/cow$currentCow"
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME,
                "${if (video) "video" else "photo"}_${System.currentTimeMillis()}.${if (video) "mp4" else "jpg"}")
            put(MediaStore.MediaColumns.MIME_TYPE, if (video) "video/mp4" else "image/jpeg")
            put(MediaStore.MediaColumns.RELATIVE_PATH, relativePath)
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val collection = if (video) MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                         else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val uri = contentResolver.insert(collection, values)
        if (uri == null) {
            Toast.makeText(this, "Could not create media file", Toast.LENGTH_LONG).show()
            return
        }
        pendingUri = uri
        pendingIsVideo = video
        intent.putExtra(MediaStore.EXTRA_OUTPUT, uri)
        if (video) {
            intent.putExtra(MediaStore.EXTRA_VIDEO_QUALITY, 1)
            intent.putExtra(MediaStore.EXTRA_DURATION_LIMIT, 300)
        }
        try {
            @Suppress("DEPRECATION")
            startActivityForResult(intent, if (video) REQUEST_VIDEO else REQUEST_PHOTO)
        } catch (e: Exception) {
            contentResolver.delete(uri, null, null)
            pendingUri = null
            Toast.makeText(this, "Could not open camera: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Camera capture result callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = pendingUri ?: return
        if (resultCode == Activity.RESULT_OK) {
            val values = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
            contentResolver.update(uri, values, null, null)
            Toast.makeText(this, "Saved to cow$currentCow", Toast.LENGTH_SHORT).show()
        } else {
            contentResolver.delete(uri, null, null)
            Toast.makeText(this, "Capture cancelled", Toast.LENGTH_SHORT).show()
        }
        pendingUri = null
    }

    companion object {
        private const val REQUEST_PHOTO = 1001
        private const val REQUEST_VIDEO = 1002
    }
}

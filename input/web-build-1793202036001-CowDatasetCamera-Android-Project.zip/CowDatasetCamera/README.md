# Cow Dataset Camera (Android)

Features:
- Capture photos and record videos using the phone's camera app.
- Stores each capture in `Pictures/CowDataset/cowN/`.
- NEW COW advances from cow1 to cow2, cow3, etc.
- Remembers the current cow number after the app is closed.

## Build an installable APK

This folder is Android Studio project source, not a precompiled APK.

1. Install Android Studio and a JDK supported by your Android Studio version.
2. Open this `CowDatasetCamera` folder in Android Studio.
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Find the APK at `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfer the APK to your Android phone and open it to install. You may need to allow installation from that source.

## Where files are saved

`Internal Storage/Pictures/CowDataset/cow1/`, then `cow2/`, etc.
You can browse the Pictures folder in your phone's Files app. Android's camera intent behavior can vary by camera app/device; test one photo and one video before collecting a large dataset.

## Notes

- Minimum Android version: Android 10 (API 29).
- The app uses the camera app already installed on the phone.
- NEW COW advances the folder number; it does not erase previous files.
